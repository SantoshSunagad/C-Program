/*
Name: Santosh Ramesh Sunagad
Date: 08\09\2023
Description: WAP to find 2nd largest element in an array
Input:Enter the size of the Array : 5
      Enter the elements into the array: 5 1 4 2 8
Output:Second largest element of the array is 5
*/

#include <stdio.h>

int sec_largest(int [], int);   //Function prototype

int main()
{
    int size, ret;  //declare the variables
    
    //Read size from the user
    printf("Enter the size of the array :");
    scanf("%d", &size);
    
    int arr[size];  //declare array
    
    //Read elements into the array
    printf("Enter the elements into the array: ");
      for(int i=0;i<size;i++)
         scanf("%d", &arr[i]);
    
    
    //funtion call
    ret = sec_largest(arr, size);
    
    printf("Second largest element of the array is %d\n", ret);
}

//Function Definition
int sec_largest(int arr[], int size){
     int f_large=0, s_large=0;
     
    for (int i=0; i<size; i++)
    {
          //condition to be check and update first large number 
        if(arr[i] > f_large)
        {
            f_large=arr[i];
        }
    }
    for(int i=0; i<size; i++)
    {
        //condition to be check and update second large number 
        if ( arr[i] > s_large && arr[i] < f_large)
        {
            s_large=arr[i];
        }
    }
    return s_large; 
}