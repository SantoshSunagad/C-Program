/*
Name: Santosh Ramesh Sunagad
Date: 31\08\2023
Description: WAP to implement your own isxdigit() function
Input:Enter the character: a
Output:Entered character is  an hexadecimal digit
*/


#include <stdio.h>

int is_xdigit(int);//Function prototype

int main()
{
       //declare the variables
    char ch;
    short ret;
    
    printf("Enter a character: ");
    scanf("%c", &ch);
    
    ret = is_xdigit(ch);
    
    /* Based on the return value of the function print the message */
    
      //check the condition print accordingly
  (ret==ch)?printf("Entered character is an hexadecimal digit"):printf("Entered character is not an hexadecimal digit");
    
    return 0;
}
//Function Definition
int is_xdigit(int ch){
    if((ch>=48 && ch<=57) || (ch>=97 && ch<=102) || (ch>=65 && ch<=70))
     return ch;
     else
     return 0;
}
