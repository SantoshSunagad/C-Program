/*
Name:Santosh Ramesh Sunagad
Date:29\08\2023
Description: WAP to print 'n' bits from LSB of a number
Input:Enter the number: 10
      Enter number of bits: 12
Output: Binary form of 10: 0 0 0 0 0 0 0 0 1 0 1 0 
*/

#include <stdio.h>

int print_bits(int, int);   //Function prototype

int main()
{
    int num, n; //declare variables
    
    printf("Enter num, n :\n");
    scanf("%d%d", &num, &n);
    
  printf("Binary form of %d:", num);
    print_bits(num, n);     //Function call
 }
 
 //Function Definition
 int print_bits(int num, int n){
   for(int i=n-1;i>=0;i--){
       if(((num>>i)&1)==1)      //checking the ith bit is set or not
       printf("1 ");
       else
       printf("0 ");
   }
 }