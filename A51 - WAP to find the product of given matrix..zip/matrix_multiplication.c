/*
Name: Santosh Ramesh Sunagad 
Date: 25/11/2023
Description:A45 - Provide a menu to manipulate or display the value of variable of type t
Input:Enter number of rows : 3
      Enter number of columns : 3
      Enter values for 3 x 3 matrix :
      1      2      3
      1      2      3
      1      2      3
      Enter number of rows : 3
      Enter number of columns : 3
      Enter values for 3 x 3 matrix :
      1      1     1
      2      2     2
      3      3     3
Output:Product of two matrix :
       14      14      14
       14      14      14
       14      14      14
*/
#include<stdio.h>
#include<stdlib.h>

int matrix_mul(int **, int **, int **, int, int, int, int);      // Function declaration
int main()
{
    int row1, col1, i, j;                                        // Declaring the variables
    // Read the row and col inputs from user for first matrix
    printf("Enter number of rows: ");
    scanf("%d", &row1);
    printf("Enter number of columns: ");
    scanf("%d", &col1);
    int **mat_a = malloc(row1 * sizeof(int *));                  // Dynamic memory allocation for matrix
    for(i=0;i<row1;i++)
    {
        mat_a[i] = malloc(row1 * sizeof(int));
    }
    printf("Enter the %dx%d matrix :\n", row1, col1);            // Dynamic memory allocation for first matrix
    for(i=0;i<row1;i++)
    {
        for(j=0;j<col1;j++)
        {
            scanf("%d", &mat_a[i][j]);
        }
    }
    int row2, col2;
    // Read the row and col inputs form user for second matrix
    printf("Enter number of rows: ");
    scanf("%d", &row2);
    printf("Enter number of columns: ");
    scanf("%d", &col2);
    //If check the condition for row and column and print error message
    if(row1 != col2 || col1 != row2)
    {
        printf("Matrix multiplication is not possible\n ");  // If row is not equal to column the print the error message
        for(int i = 0; i < row1; i++)
        {
            free(mat_a[i]);
        }
        free(mat_a);
        return 0;
    }
    int **mat_b = malloc(row2 * sizeof(int *));              // Dynamic memory allocation for second matrix

    for(i=0;i<row2;i++)
    {
        mat_b[i] = malloc(row2 * sizeof(int));
    }

    printf("Enter the %dx%d matrix :\n", row2, col2);       // If row and column is equal then print this message
    for(i=0;i<row2;i++)
    {
        for(j=0;j<col2;j++)
        {
            scanf("%d", &mat_b[i][j]);
        }
    }
    int **result = calloc(row1 * sizeof(int *), sizeof(int));   // Dynamic memory allocation for store the result
    for(i=0;i<row1;i++)
    {
        result[i] = calloc(row2 * sizeof(int), sizeof(int));
    }
    matrix_mul(mat_a, mat_b, result, row1, col1, row2, col2);    // Function call
    printf("product of two matrix:\n");                          // Print product output of the matrix
    for(i=0;i<row1;i++)
    {
        for(j=0;j<col2;j++)
        {
            printf("%d ", result[i][j]);
        }
        printf("\n");
    }
    for(int i = 0; i < row1; i++)                                // Free the memory of matrices at last
    {
        free(mat_a[i]);
    }
    free(mat_a);

    for(int i = 0; i < row2; i++)
    {
        free(mat_b[i]);
    }
    free(mat_b);

    for(int i = 0; i < row1; i++)
    {
        free(result[i]);
    }
    free(result);

    return 0;
}

int matrix_mul(int **m_a, int **m_b, int **res, int row1, int col1, int row2, int col2)   // Function definition
{
    int i, j, k;        // Declaring the variable
    // Logic to product the 2 matrices
    for(i=0;i<row1;i++)
    {
        for(j=0;j<col2;j++)
        {
            for(k=0;k<col1;k++)
            {
                res[i][j] += m_a[i][k] * m_b[k][j];
            }
        }
    }
}