/*
Name: Santsoh Ramesh Sunagad
Date: 29\08\2023
Description: WAP to get 'n' bits of a given number 
Input: Enter the number: 10
       Enter number of bits: 3
Output: Result = 2
*/

#include <stdio.h>

int get_nbits(int num, int n);  //Function prototype

int main()
{
    int num, n, res = 0;    //declare variable
    
    printf("Enter num and n:");
    scanf("%d%d", &num, &n);
    
    res = get_nbits(num, n);    //Function call and result store in variablbe 'res'.
    
    printf("Result = %d\n", res);
}

//Function Definition
int get_nbits(int num, int n){
    int res;
  res=(num&(1<<n)-1);   //to get LSB of 'n' bits of values 
  return res;
}
