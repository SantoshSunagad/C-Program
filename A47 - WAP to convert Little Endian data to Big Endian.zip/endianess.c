/*
Name: Santosh Ramesh Sunagad
Date: 25/11/2023
Description : A47 - WAP to convert Little Endian data to Big Endian
Sample Input: Enter the size: 2
              Enter any number in Hexadecimal: ABCD
Sample Output: After conversion CDAB
*/

#include<stdio.h>
    int main()
    {
        int size, num;    // declare the integer variables
        printf("Enter the size: ");
        scanf("%d", &size);  // read the size value
        printf("Enter any number is Hexadecimal: ");
        scanf("%X", &num);  // read the num value
        
        char *ptr = (char *)&num;  // declare the character poiter
        char temp;  
        if (size==2)   // check the condition size is equal to 2 or not
        {
            temp=*ptr;  // assign the *ptr value to the temp value
            *ptr=*(ptr+1); // perform swapping operations for 2 numbers and store in temp variable
            *(ptr+1)=temp;
        }
        else if (size==4)   // check the condition size value is equal to 4 or not
        {
            char temp1;
            temp=*ptr;  // perform swapping operations for four numbers
            *ptr=*(ptr+3);
            *(ptr+3)=temp;
            temp1=*(ptr+1);
            *(ptr+1)=*(ptr+2); // perform swapping operations for a two numbers stored in num variable 
            *(ptr+2)=temp1;
        }
        printf("After conversion %X", num);  // print the num value
}