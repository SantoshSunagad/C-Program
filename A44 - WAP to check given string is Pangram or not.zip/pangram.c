/*
Name: Santosh Ramesh Sunagad
Date: 03\10\2023
Description:WAP to check given string is Pangram or not
Input:Enter the string: The quick brown fox jumps over the lazy do
Output:The Entered String is a Pangram String
*/
#include <stdio.h>

int pangram(char []);   //Function prototype

int main()
{
    char str[100];  //declare the string array
    printf("Enter the string:");
    fgets(str,100,stdin);   //read  the user input by using standard I/O
    
    int ret=pangram(str);
    (ret==26)?printf("The Entered String is a Pangram String"):printf("The Entered String is not a Pangram String");
 
}
//Function Definition
int pangram(char *str){
    int arr[26]={0}, i, count=0;    //declare the array and variables
    //loop run untill '\0' character
    while(*str){
        if(*str>='A' && *str<='Z' || *str>='a' && *str<='z'){       //condition to be upper or lower case with in the range
            if(*str>='A' && *str<='Z')  //condition to be only upper case character A-Z
                 i=(*str-'A');  //expression to find index number upper case
            else
                 i=(*str-'a');  //expression to find index number lower case
                 
                 arr[i]=1;      //assign to i'th number index to 1.
        } 
        str++;          //increment the address to get next character
    }
    i=0;    //upadte the i value by zero
    while(i<26){
        (arr[i++]==1)?++count:0;    //check how many 1's are present
    }
    return count;       //return the count value to main function
}