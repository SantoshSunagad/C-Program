/*
Name: Santosh Ramesh Sunagad
Date: 26\08\2023
Description:WAP to print all primes using Sieve of Eratosthenes method.
Input:Enter the value of 'n' : 20
Output:The primes less than or equal to 20 are : 2, 3, 5, 7, 11, 13, 17, 19
*/


#include<stdio.h>  
int main()  
{  
    int N, i, j;
    printf("Enter the value of 'n':");
    scanf("%d", &N);    //read the size of array
    if(N>1){
    int array[N];
  //insert the values in array
    for(i=0;i<N;i++)  
        array[i]=i+1;  
  //find prime number using sieve of Eratosthenes method
    for(i=1;i<N;i++){  
        if(array[i]!=0){  
            for(j=array[i]*array[i];j<=N;j=j+array[i])  
                array[j-1]=0;  
        }  
    }  
    //display only non zero values of array (prime number)
    printf("The primes less than or equal to %d are :", N);
    for(i=1; i<N;i++){  
        if(array[i] != 0)  
            printf("%d, ", array[i]);  
    }  
}
else
printf("Please enter a positive number which is > 1");
    
    return 0;  
}  