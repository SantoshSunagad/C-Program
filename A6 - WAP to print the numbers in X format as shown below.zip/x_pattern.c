/*
Name: Santosh Ramesh Sunagad
Date: 21\08\2023
Description: WAP to print the numbers in X format as shown below
Input: Enter the number: 4
Output:1  4
        23
        23
       1  4
*/

#include<stdio.h>
int main()
{
    int i, j, n; //declare the variables
    
    printf("Enter the number:");
    scanf("%d", &n);
     //looprun according input and genrate pattern
    for(i=0;i<=n;i++){
        for(j=1;j<=n;j++){
         
             if(i == j || i+j == n+1 ){
                printf("%d", j);
            }
            else
            {
                printf(" ");
            }
        }
        printf("\n");
    }
    
    return 0;
}
//End of the program
