/*
Name: Santosh Ramesh Sunagad
Date: 10\10\2023
Description: WAP to define a macro swap (t, x, y) that swaps 2 arguments of type t
Input: 1. Int
       2. char
       3. short
       4. float
       5. double
       6. string
       Enter you choice : 1
       Enter the num1 : 10
       Enter the num2 : 20
Output: After Swapping :
        num1 : 20
        num2 : 10
*/

#include<stdio.h>
#include<stdlib.h>
//marco for swaping 2 argument
#define SWAP(data_type,a,b)	\
{                  	        \
    data_type temp = a;    	\
    a = b;      	        \
    b = temp;               \
}
int main()
{
    int choice;
    printf("1. Int\n2. char\n3. short\n4. float\n5. double\n6. string\nEnter you choice : ");
    scanf("%d", &choice);       //read the user choice
    
    switch(choice)
    {
        case 1:            
             {     //Integer value swapping
                   int num1, num2;
                   printf("Enter the num1:");
                   scanf(" %d", &num1);
                   printf("Enter the num2:");
                   scanf(" %d", &num2);
                   printf("After Swapping:\n");
                   SWAP(int , num1, num2);                      //macro will replace with definition
                   printf("num1: %d\nnum2: %d", num1, num2);
             }
                break;
        case 2:   
             {     //Character swapping
                   char ch1, ch2;
                   printf("Enter the character 1:");
                   scanf(" %c", &ch1);
                   printf("Enter the character 2:");
                   scanf(" %c", &ch2);
                   printf("After Swapping:\n");
                   SWAP(char , ch1, ch2);                       //macro will replace with definition               
                   printf("character 1: %c\ncharacter 2: %c", ch1, ch2);
             }
                break;
        case 3:   
             {
                     short num1, num2;
                     printf("Enter the num1:");
                     scanf(" %hd", &num1);
                     printf("Enter the num2:");
                     scanf(" %hd", &num2);
                     printf("After Swapping:\n");
                     SWAP(short , num1, num2);                  //macro will replace with definition
                     printf("num1: %hd\nnum2: %hd", num1, num2);
             }
                 break;
        case 4:    
             {       float num1, num2;
                     printf("Enter the num1:");
                     scanf(" %f", &num1);
                     printf("Enter the num2:");
                     scanf(" %f", &num2);
                     printf("After Swapping:\n");
                     SWAP(float , num1, num2);                  //macro will replace with definition
                     printf("num1: %f\nnum2: %f", num1, num2);
             }
                 break;
        case 5:   
             {
                    double num1, num2;
                     printf("Enter the num1:");
                     scanf(" %lf", &num1);
                     printf("Enter the num2:");
                     scanf(" %lf", &num2);
                     printf("After Swapping:\n");
                     SWAP(double , num1, num2);                 //macro will replace with definition
                     printf("num1: %lf\nnum2: %lf", num1, num2);
             }
                break;
        case 6:    
             {
		             char *ch1, *ch2;                           //declare character pointers
         
		             ch1 = calloc(20,sizeof(char));             //Dyanamic memory allocation for character pointer 1 
		             ch2 = calloc(20,sizeof(char));             //Dyanamic memory allocation for character pointer 2
         
		             printf("Enter the string1: ");
		             scanf("%s",ch1);
		             printf("Enter the string2: ");
		             scanf("%s",ch2);
         
		             SWAP(char *, ch1, ch2);                    //macro will replace with definition
         
		             printf("\nAfter swapping\n");
		             printf("string1 is: %s\nstring2 is: %s\n",ch1, ch2);   
         
		             free(ch1);                                //clean up the pointer 1
		             free(ch2);	                               //clean up the pointer 2
		     }
		         break;
		default :
		            printf("Invalid input");
		            break;
    }
}