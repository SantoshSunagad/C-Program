/*
Name: Santosh Ramesh Sunagad
Date: 01\09\2023
Description:WAP to replace 'n' bits of a given number
Input: Enter a number: -8
Output: 0, 1, -1, 2, -3, 5, -8
*/

#include <stdio.h>

void negative_fibonacci(int, int, int, int);

int main()
{
    int limit;      //declare the variable
    
    printf("Enter the limit : ");
    scanf("%d", &limit);    //read the num value
    
    negative_fibonacci(limit, 0, 1, 0); //Function call 
}
//Function Definition
void negative_fibonacci(int limit, int a, int b, int sub){
    //condition to be check limit is lessthan or equal to 0 or not
     if(limit<=0){       
        //condition to be check for genrate negative fibb0nacci
        if(a>=limit && a<=-limit){       
            printf(" %d", a);
            sub=a-b;
            a=b;        //swiping a in b
            b=sub;      //swiping b in 'sub' value
            negative_fibonacci(limit, a, b, sub);   //Function call recursively
        }
    } 
    else
        printf("Invalid input");
}