/*
Name: Santosh Ramesh Sunagad 
Date: 29\08\2023
Description:  WAP to get 'n' bits from given position of a number
Input:Enter the number: 15
      Enter number of bits: 2
      Enter the pos: 2
Output: Result = 3
*/

#include <stdio.h>

int get_nbits_from_pos(int, int, int);  //Function prototype

int main()
{
    int num, n, pos, res = 0;   //declare variables
    
    printf("Enter num, n and val:");
    scanf("%d%d%d", &num, &n, &pos);
    
    res = get_nbits_from_pos(num, n, pos);  //Function call and result will store in variable 'res'
    
    printf("Result = %d\n", res);
}
//Function defintion
int get_nbits_from_pos(int num, int n, int pos){
    int res;
     res=(num>>((1+pos)-n)) & ((1<<n)-1);     //logic for 'n' bits from given position of number
    return res;
}