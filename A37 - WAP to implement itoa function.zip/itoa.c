/*
Name: Santosh Ramesh Sunagad
Date: 30\09\2023
Description: WAP to implement itoa function
Input and Output:
1.Enter the number : 1234
  Integer to string is 1234
2.Enter the number : -1234
  Integer to string is -123
3.Enter the number : +1234
  Integer to string is 1234
4.Enter the number : a1234
  Integer to string is 0
*/

#include <stdio.h>
#include<string.h>

void itoa(int num, char str[]);     //Function prototype

int main()
{
    int num;
    char str[10];   //declare the character array
    
    printf("Enter the number:");
    if((scanf("%d", &num)) == 1)        //scanf function return 1 is check condition
    {

    itoa(num, str);     //Function call
    }
    else
    {
        num=0;
        itoa(num, str);     //Function call

    }
    printf("Integer to string is %s", str);
}

//Function Definition
void itoa(int num, char str[]){
     int i=0, j;
    char temp=0;
    //condition check number positive or negative
    if(num<0){
        num=-num;
        str[i]='-';
        i++;
        j=1;
    }
    else
     j=0;
    //Convering integer to string
    while (num!=0)
    {
            int rem=num%10;
            str[i++]=rem+'0';
            num=num/10;
    }
   (i==0)?(str[i]='0'):(str[i]='\0');
    int len=strlen(str)-1;  //taking length of string
    //this loop for string reversal
    while(j<=len){
       temp=str[j];
       str[j]=str[len];
       str[len]=temp;
       len--;
       j++;
    }
   
}
