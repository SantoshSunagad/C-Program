/*
Name: Santosh Ramesh Sunagad
Date: 07\08\2023
Description: WAP to generate positive Fibonacci numbers
Input: Enter a number: 8
output: 0 1 1 2 3 5 8
*/


#include<stdio.h>
int main()
{
    int sum, N, i=0;  //declare the variables 
    int a=0, b=1;   // initialize the a and b variables
    printf("Enter a number:");
    scanf("%d", &N);    //read the user input and store in 'N' variable
    
    //check the condition foe given number is positive or negative
    if(N>=0){       
        
        //check the condition user input is zero or not
        if(N == 0)  
        printf("%d", a);
        else
        {
            printf(" %d", a);
         printf(" %d", b);
        }
        
        //loop run untill given condition true
         while(i<=N){
        
            sum=a+b;
            a=b;    //swapping
            b=sum;  //swapping
            
            
            //check condition sum is lessthan N 
                    if(sum <= N) {
                   printf(" %d", sum);
                    }
                    i++;    //increment by 1
            }
        }
    else
    {
        printf("Invalid input");
    }
    
    return 0;
}

//End the program