/*
Name: Santosh Ramesh Sunagad 
Date: 25/11/2023
Description: A48 - WAP to generate a n*n magic square
Sample Input: Enter a number: 3
Sample Output: 8 1 6
               3 5 7
               4 9 2
*/

#include <stdio.h>
#include<stdlib.h>

void magic_square(int **, int);  // function prototype

int main()
{
    int num, i,j;   // declare the integer variables
    printf("Enter the number : ");
    scanf("%d", &num);  // read the num value
    
    if (num%2==0 || num < 0)  // check the condition num value is positive or not
    {
        printf("Error : Please enter only positive odd numbers\n");
       return 0;
    }
    int **arr;  // declare the integer array
    arr= calloc (num, sizeof(int*));  // dynamic memory allocation
        for(int i=0; i<num; i++)
        {
                arr[i]= calloc (num, sizeof(int));
        }
        magic_square(arr,num);  // function call
        free(arr);
}
void magic_square(int **arr, int n)  // function definition
{
    int col, row = 0, num, i;  // declare the integer  variables
    col = n/2;   
    num=n*n;
    for (int i=1; i<=num; i++)  // loop runs the 1 to until less than num value
    {
        arr[row][col]=i;
        if(i%n==0)
        {
            row++;  // increament the row value
        }
        else
        {
            if(row==0)  // check the condition row value is equal to 0 or not
            {
                row = n-1;
            }
            else
            {
                row--;  // decreament the row value
            }
            if(col==(n-1))
            {
                col=0;  // sssign the 0 to col
            }
            else
            {
                col++;  // increament the col value
            }
            }
        }
        for(row=0; row<n; row++)  // loops runs the 0 to until less than row value 
        {
            for(col=0; col<n; col++)  // loop runs the 0 to until less than n value 
            {
                printf("%3d", arr[row][col]);  // print the array variables
            }
    printf("\n");  // new line
    }
}