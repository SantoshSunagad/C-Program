/*
Name: Santosh Ramesh Sunagad
Date: 06/09/2023
Description: WAP to implement Circular left shift
Sample Input: Enter num: 12
              Enter n : 3
Sample Output: Result in Binary: 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 0 0 0 0 0
*/

#include <stdio.h>
// function prototype
int circular_left(unsigned int num ,unsigned int n); 
int print_bits(int ret); 

int main()
{
    int num, n, ret; // Declare integer variables num, n, and ret.
    
    printf("Enter num:"); 
    scanf("%d", &num); // read the num value
    
    printf("Enter n:");
    scanf("%d", &n); // read the n value
    printf("Result in Binary: ");
    
    ret = circular_left(num, n);  //Function call
    print_bits(ret); // Function call
    
}
    
    // function Definition (circular_left) 
    int circular_left(unsigned int num,unsigned int n) {
        int res; // declare variable res
        // Perform a circular left shift on 'num' by 'n' bits and combine it with a circular right shift.
        res=(num<<n) | (num >> (32-n)); 
        return res;  // Return the result after circular shifting.
    }
    //Function Definition (print_bits)
        int print_bits(int ret){ 
         for (int i=31; i>=0; i--)  // loop runs the 31 to 0 times
         ((ret&(1<<i))==0) ? printf("0 ") : printf("1 "); // Check if the ith bit of ret is 0 and print '0', otherwise print '1'.
    }