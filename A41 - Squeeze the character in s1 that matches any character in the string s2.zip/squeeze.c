/*
/*
Name: Santosh Ramesh Sunagad
Date: 10\03\2023
Description: Squeeze the character in s1 that matches any character in the string s2
Input and Output:
case 1: Enter s1 : Dennis Ritchie
        Enter s2 : Linux
        Output: After squeeze s1 : Des Rtche
case 2: Enter s1 : Welcome
        Enter s2 : Emertxe
        Output: After squeeze s1 : Wlco
*/
#include <stdio.h>

void squeeze(char [], char []); //Function Prototype

int main()
{
    char str1[30], str2[30];    //declare the string array
    
    printf("Enter string1:");
    scanf("%[^\n]", str1);
    

    printf("Enter string2:");
    scanf(" %[^\n]", str2);
    
    squeeze(str1, str2);        //Function Call
    
    printf("After squeeze s1 : %s\n", str1);
    
}
//Function Definition
void squeeze(char str1[], char str2[]){
    int i,j, flag, ind=0;
    for(i=0;str1[i]!='\0';i++){         //loop run untill string 1 get NULL character
        flag=0;
        for(j=0;str2[j]!='\0';j++){     ////loop run untill string 2 get NULL character
            if(str1[i]==str2[j]){           //if matches string 1 to string 2
                flag=1;                     //Update flag value and break the loop
                break;
            }
        }
        if(flag==0){                    //flag equal 0 then update string update index
        str1[ind]=str1[i];
        ind++;                          //post increment index
        }
    }
    str1[ind]='\0';                    //Adding NULL character
}