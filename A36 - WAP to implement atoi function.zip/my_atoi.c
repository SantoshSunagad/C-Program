/*
Name: Santosh Ramesh Sunagad
Date: 29\09\2023
Description: WAP to implement atoi function
Input and Output:
case 1: Enter a numeric string: -12345
        Output: String to integer is -12345
case 2: Enter a numeric string: +12345
        String to integer is 12345
case 3: Enter a numeric string: +-12345
        String to integer is 0
case 4: Enter a numeric string: abcd12345
        String to integer is 0
case 5: Enter a numeric string: 12345abcd
        String to integer is 12345
case 6: Enter a numeric string: 12345
        String to integer is 12345
*/

#include <stdio.h>
int my_atoi(const char []); //Funtion prototype

int main()
{
    char str[20];   //declare character type string array
    
    printf("Enter a numeric string : ");
    scanf("%s", str);
    
    printf("String to integer is %d\n", my_atoi(str));      //calling Function in printf function
}
//Function definition
int my_atoi(const char str[]){
    int i=0, flag=1, sum=0; //declare variable
    while("str[i]!='\0"){   
        if(str[i]=='-'&& i==0){ //condition check 1st index character is '-' or not
            flag=-1;        //update flag
            i++;
        }
        (str[i]=='+')?i++:0; //condition check character is '+' or not using ternary operator
        if(str[i]>='0' && str[i]<='9'){
            sum=sum*10+str[i]-'0';      //string will convert to integer
            i++;
        }
        else
        break;
    }
    return sum*flag;
    
}
