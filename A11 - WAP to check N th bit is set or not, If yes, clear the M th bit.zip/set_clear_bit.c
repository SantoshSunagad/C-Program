/*
Name: Santosh Ramesh Sunagad
Date: 21\08\2023
Description: WAP to check N th bit is set or not, If yes, clear the M th bit
Input: Enter the number: 19
       Enter 'N': 1
       Enter 'M': 4
Output: Updated value of num is 3
*/

#include<stdio.h>
int main()
{
    int num, N, M; //declare the variables

            printf("Enter the number:");
            scanf("%d", &num);
            
            printf("Enter 'N':");
            scanf("%d", &N);
            
            printf("Enter 'M':");
            scanf("%d", &M);

            //check the condition Nth bit Set(1) or Not
            if(1==((num >> N)& 1)){
            num=(num&(~(1<<M))); //if condition gets true then clear the M th bit
           printf("Updated value of num is %d", num);
            }
            else{
            printf("Updated value of num is %d", num);
            }
            return 0;
}
//End of the program