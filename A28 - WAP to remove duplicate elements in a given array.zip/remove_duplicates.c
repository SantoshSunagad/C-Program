/*
Name:Santosh Ramesh Sunagad
Date:11\09\2023
Description: WAP to remove duplicate elements in a given array
Input:Enter the size: 5
      Enter elements into the array: 5 1 3 1 5
Output: After removing duplicates: 5 1 3
*/
#include <stdio.h>
void fun(int *arr1, int size, int *arr2, int *new_size);  //Function prototype

int main()
{
    int size;   //declare size datatype
    
    printf("Enter the size:");
    scanf("%d", &size); //read the size 
    
    int arr1[size], arr2[size], new_size=0; //declare the array's
    //loop run for read the arr1 elements
    printf("Enter elements into the array: ");
    for(int i=0;i<size;i++)
    scanf("%d", &arr1[i]);
    //Function call
    fun(arr1, size, arr2, &new_size);
    //After removing duplicates 
    printf("After removing duplicates: ");
    for(int i=0; i<new_size; i++)
        printf("%d ", arr2[i]);
    return 0;
}
//Function Definition 
void fun(int arr1[], int size, int arr2[], int *new_size){
if (size==0)
{
    return;
}
     arr2[0]=arr1[0];   //assign array1 1st element to array2 1st element
     *new_size =1;  //intilizing new size
    for(int i=1;i<size;i++){
         int flag=0;
            for(int j=0;j<*new_size;j++){
                //comparing array1 element to array2 present all element
                if(arr1[i]==arr2[j]){
                    flag=1;
                    break;
                }
            }
                    //flag value zero then update the array2 
                    if(flag==0){
                        arr2[*new_size]=arr1[i];
                         (*new_size)++;     
                    }    
    }
}

