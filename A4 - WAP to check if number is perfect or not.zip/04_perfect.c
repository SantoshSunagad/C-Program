/*
Name: Santosh Ramesh Sunagad
Date: 09\08/2023
Description: A4 - WAP to check if number is perfect or not
Input:    Enter a number: 6
Output:  Yes, entered number is perfect number
*/

#include<stdio.h>
int main()
{
  int i=1,N,div;   //declare the variables
  int  temp=0;  //initilize the temp variable
  
    printf("Enter a number:");
    scanf("%d",&N); //read the user input
    
    
    //check the user input is positive or not
    if(N<=0){
          printf("Error:Invalid Input, Enter only positive number");
    }
    else
    {
        //loop run untill lessthan or equal to N
        while(i<=N){            
        //check the reminder is zero or not
        if(N%i == 0){ 
            temp=temp+i;
            div=temp/2;
        }
        i++;
    }
    
    //compare the user input and division of 2 equal or not
    if(div==N){
            printf("Yes, entered number is perfect number");
         }
         else
         {
            printf("No, entered number is not a perfect number");
         }
        
    }
    

    return 0;
}
//End the program