/*
Name: Santosh Ramesh Sunagad
Date: 12\09\2023
Desciption: WAP to implement getword function 
Input: Enter the string: Welcome to Emertxe
Output: You entered Welcome and the length is 7
*/

#include <stdio.h>

int getword(char str[]);    //Function prototype

int main()
{
        int len = 0;    //declare the variables
	    char str[100];  //declare the string

		printf("Enter the string : ");
		scanf(" %[^\n]", str);      //read the user input

		len = getword(str);     //Function call 

        printf("You entered %s and the length is %d\n", str, len);
}

//Function Definition
int getword(char str[]){
    int i=0;
    //loop rou untill get space character
    while(str[i]!=' ' && str[i]!='\0'){
          i++;
    }
    str[i]='\0';    //adding NULL character to string
    return i;
}
