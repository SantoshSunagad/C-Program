/*
Name: Santosh Ramesh Sunagad
Date: 08\09\2023
Description: WAP to find 3rd largest element in an array
Input:Enter the size of the Array : 5
      Enter the elements into the array: 5 1 4 2 8
Output: Third largest element of the array is 4
*/

#include <stdio.h>

int third_largest(int [], int); //Function prototype

int main()
{
    int size, ret;  //declare variables
    
    //Read size from the user
    printf("Enter the size of the array :");
    scanf("%d", &size);
    
    int arr[size];
    
    //Read elements into the array
    printf("Enter the elements into the array:");
     for(int i=0;i<size;i++)
    scanf("%d", &arr[i]);
    
    //funtion call
    ret = third_largest(arr, size);
    
    printf("Third largest element of the array is %d\n", ret);
}
//Function definition
int third_largest(int arr[], int size){
   
     int f_large=0, s_large=0, t_large=0;
  
    for (int i=0; i<size; i++){
        // //condition to be check and update first large num
        if(arr[i] > f_large)
            f_large=arr[i];
    }
    for(int i=0; i<size; i++){
        //condition to be check and update second large number 
        if (arr[i]>s_large && arr[i]<f_large)
            s_large=arr[i];
    }
    for(int i=0;i<size;i++){
        //condition to be check and update Third large number 
        if (arr[i]>t_large && arr[i]<f_large && arr[i]<s_large)
            t_large=arr[i];
    }
    return t_large;
}