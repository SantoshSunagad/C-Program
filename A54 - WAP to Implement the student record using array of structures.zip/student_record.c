/*
Name: Santosh Ramesh Sunagad
Date: 25/11/2023
Description: A54 - WAP to Implement the student record using array of structures
Sample Input:Enter no.of students : 2
             Enter no.of subjects : 2
             Enter the name of subject 1 : Maths
             Enter the name of subject 2 : Science
             ----------Enter the student datails-------------
             Enter the student Roll no. : 1
             Enter the student 1 name : Nandhu
             Enter Maths mark : 99
             Enter Science mark : 91
             ----------Enter the student datails-------------
             Enter the student Roll no. : 2
             Enter the student 2 name : Bindhu
             Enter Maths mark : 88
             Enter Science mark : 78
             ----Display Menu----
             1. All student details
             2. Particular student details
             Enter your choice : 2
Sample Output:----Menu for Particular student----
              1. Name.
              2. Roll no.
              Enter you choice : 1
              Enter the name of the student : Nandhu
              Roll No.   Name           Maths         Science       Average       Grade
              1              Nandhu        99               91                95                  A
              Do you want to continue to display(Y/y) : n
*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct student // declare the structure
{
    // declaring the structure variables
    int roll_no[10];  
    char name[20][100];
    char grade[10];
    float avg;
    int marks[10][100];
};

int main()
{
    struct student s1;  // declare the structure variables
    char ch;
    int std, sub, sum=0, i, j, opt, num;  // read the integer variables
    printf("Enter no.of students : ");
    scanf("%d", &std);     // read the std value
    printf("Enter no.of subjects : ");
    scanf("%d", &sub);   // read the sub value

    char arr[sub][100];   // declare the array string
    for(i=0; i<sub; i++)   // loop runs the 0 to until less than of sub value
    {
        printf("Enter the name of subject %d : ", i+1);
        scanf("%s", arr[i]);
    }

for( i=0; i<std; i++)     // loop runs the  0 to until less than of std value
{
    printf("\n----------Enter the student datails-------------\n");
    printf("Enter the student Roll no. : ");
    scanf("%d", &s1.roll_no[i]);
    printf("Enter the student %d name : ", i+1);
    scanf("%s", s1.name[i]);

for(j=0; j<sub; j++)
{
    printf("Enter %s mark : ", arr[j]);
    scanf("%d", &s1.marks[i][j]);
sum += s1.marks[i][j];
}
s1.marks[i][j]=sum/sub;
if (s1.marks[i][j] >= 91 && s1.marks[i][j] <= 100)    //check the marks grades
{
     s1.grade[i]='A';
}
else if (s1.marks[i][j] >= 81 && s1.marks[i][j] <= 90)
{
     s1.grade[i]='B';
}
else if (s1.marks[i][j] >= 71 && s1.marks[i][j] <= 80)
{
     s1.grade[i]='C';
}
else if (s1.marks[i][j] >= 61 && s1.marks[i][j] <= 70)
{
     s1.grade[i]='D';
}
else if (s1.marks[i][j] >= 51 && s1.marks[i][j] <= 60)
{
     s1.grade[i]='E';
}
else 
{
     s1.grade[i]='F';
}
sum=0;
}
do
{
printf("----Display Menu----\n1. All student details\n2. Particular student details\n");
int choice1,  choice2;    // declare the integer variables

printf("Enter your choice : ");
scanf("%d", &choice1);  // read the choice1 value
switch (choice1)
{
    case 1:
    {
        printf("%-8s %-15s", "Roll.no", "Name");
        for(int i=0; i<sub; i++)
        {
            printf("%-10s", arr[i]);
        }
        printf("%-10s %-10s\n", "Average", "Grade");
        
        for( i=0; i<std; i++)
        {
        printf("%-8d %-15s", s1.roll_no[i], s1.name[i]);
         
           for(j=0; j<sub; j++)
            {
            printf("%-10d", s1.marks[i][j]);
        }
        printf("%-10d %-10c\n", s1.marks[i][j], s1.grade[i]);
        }
        break;
    }
    case 2:
    {
     printf("\n\n----Menu for Particular student----\n1. Name.\n2. Roll no.\nEnter you choice : ");   
     scanf("%d", &opt);    // read the opt value
     switch(opt)
     {
         case 1:
         {
           int temp, count=0;
           char srd[50];
             printf("Enter the roll number of the student : ");
             scanf("%s", srd);
             for(i=0; i<std; i++)
             {
                 if(strcmp(s1.name[i], srd) == 0)
                 {
                     temp=i;
                     count=1;
                     break;
                 }
             }
             if(!count)
             {
                 printf("Invalid Name\n");
                 return 0;
             }
       printf("%-8s %-15s", "Roll.no", "Name");
        for(int i=0; i<sub; i++)
        {
            printf("%-10s", arr[i]);
        }
        printf("%-10s %-10s\n", "Average", "Grade");
                printf("%-8d %-15s", s1.roll_no[temp], s1.name[temp]);
           for(j=0; j<sub; j++)
            {
            printf("%-10d", s1.marks[temp][j]);
        }
        printf("%-10d %-10c\n", s1.marks[temp][j], s1.grade[temp]);
        }
         break;
         case 2:
         {
             int temp, count=0;
             printf("Enter the roll number of the student : ");
             scanf("%d", &num);
             for(i=0; i<std; i++)
             {
                 if(num==s1.roll_no[i])
                 {
                     temp=i;
                     count=1;
                     break;
                 }
             }
             if(!count)
             {
                 printf("Invaild Roll Number\n");
                 return 0;
             }
       printf("%-8s %-15s", "Roll.no", "Name");
        for(int i=0; i<sub; i++)
        {
            printf("%-10s", arr[i]);
        }
        printf("%-10s %-10s\n", "Average", "Grade");
                printf("%-8d %-15s", s1.roll_no[temp], s1.name[temp]);
           for(j=0; j<sub; j++)
            {
            printf("%-10d", s1.marks[temp][j]);
        }
        printf("%-10d %-10c\n", s1.marks[temp][j], s1.grade[temp]);
        }
             
         }
         break;
         default:
         printf("Invaild choice\n");
     }
    break;
}
printf("Do you want to continue to display(Y/N) : ");
scanf(" %c", &ch);
while((getchar()) != '\n');
}while(ch != 'N');
return 0;
}
    








