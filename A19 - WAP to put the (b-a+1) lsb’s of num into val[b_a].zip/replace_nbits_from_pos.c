/*
Name: Santosh Ramesh Sunagad
Date: 30\08\2023
Description: WAP to put the (b-a+1) lsb’s of num into val[b:a]
Input:Enter the value of 'num' : 11
      Enter the value of 'a' : 3
      Enter the value of 'b' : 5
      Enter the value of 'val': 174
Output: Result : 158
*/

#include <stdio.h>

int replace_nbits_from_pos(int, int, int, int); //Function Prototype

int main()
{
    int num, a, b, val, res = 0;    //declare variables
    
    printf("Enter num, a, b, and val:");
    scanf("%d%d%d%d", &num, &a, &b, &val);  //read user input
    
    //Function call and result will store in variable 'res'
    res = replace_nbits_from_pos(num, a, b, val);   
    
    printf("Result = %d\n", res);
}

//Function Definition
int replace_nbits_from_pos(int num, int a, int b, int val){
    int n=b-a+1, clear_bits_range, Take_num_bit;
    clear_bits_range=val&~(((1<<(n))-1)<<(a)); //clrat the bit in given value
    
   Take_num_bit=(num&((1<<(n))-1)) << (n); //taking the 'n' number of bit's
   
     //bitwise OR operation between val and replace the number of bit's
    return Take_num_bit | clear_bits_range;    
}