/*
Name: Santosh Ramesh Sunagad
Date: 28\08\2023
Description:WAP to check whether a given number is prime or not.
Input:Enter a number: 2
Output:2 is a prime number
*/

#include <stdio.h>
int main()
{
   int num;
   int flag=0; //initilize the flag variable
   //read the user input
  // printf("Enter a number: ");
   scanf("%d", &num);
   if(num<=1)
    printf("Invalid input");
    else
    {
      for(int i=2;i<num;i++){
       //if the number is prime and update flag by 1
       if(num%i==0){
           flag=1;
           break;
        }
      }
            //condition to be check flag is equal to 1 or not
            if(flag==1)
            printf("%d is not a prime number", num);
            else
               printf("%d is a prime number", num);
               
    }
      
   return 0;
}
//End of the program