/*
Name: Santosh Ramesh Sunagad
Date: 01\09\2023
Description: WAP to find factorial of given number using recursion
Input:Enter the value of N : 7
Output: Factorial of the given number is 5040
*/

#include <stdio.h>

int main()
{
    //declare static variables
    static int num; 
    static unsigned long long int fact = 1;

      
      //read the user input
        if(fact==1){
        printf("Enter the value of N :");
            scanf("%d", &num);
        }
        
            //user input is greater than 0 or not
            if(num>=0){  
                if(num!=0){
                   fact=fact*(num--);   //to find factorial number logic
                     main();    //Function call recursively
                }
                else
                printf("Factorial of the given number is %lld", fact);
            }
            else
            printf("Invalid Input");

    return 0;
}
//End of the program