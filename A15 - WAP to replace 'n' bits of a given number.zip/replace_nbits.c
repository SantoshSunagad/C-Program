/*
Name: Santosh Ramesh Sunagad
Date: 28\08\2023
Description:WAP to replace 'n' bits of a given number
Input:Enter the number: 10
      Enter number of bits: 3
Output: Result = 12
*/

#include <stdio.h>

int replace_nbits(int, int, int);   //Function prototype

int main()
{
    int num, n, val, res = 0;   //declare the variables
    
    printf("Enter num, n and val:");
    scanf("%d%d%d", &num, &n, &val);
    
    res = replace_nbits(num, n, val);   //Function call and result will store in variable 'res'
    
    printf("Result = %d\n", res);
}
//Function Definition
int replace_nbits(int num, int n, int val){
    int res;
    res=(num&~(1<<n)+1)|val;        //logic for replace 'n' bits 
    return res;
}