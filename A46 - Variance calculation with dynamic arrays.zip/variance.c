/*
Name: Santosh Ramesh Sunagad
Date: 11\10\2023
Description: Variance calculation with dynamic arrays
Input: Enter the no.of elements : 10

Enter the 10 elements:
[0] -> 9
[1] -> 12
[2] -> 15
[3] -> 18
[4] -> 20
[5] -> 22
[6] -> 23
[7] -> 24
[8] -> 26
[9] -> 31

Output: Variance is 40.000000
*/

#include <stdio.h>
#include<stdlib.h>

float variance(int *, int);     //Function prototype

int main()
{
    int N, Sum_of_ele=0;
    float Mean;     //declare the variables

    printf("Enter the No.of elements: ");
    scanf("%d", &N);
    int *arr, *D_sqr;                   //declare array's
    arr=(int *)malloc(N*sizeof(int));   //Dynamic Memory Allocation for arr array 
    D_sqr=(int *)calloc(N,sizeof(int)); //Dynamic Memory Allocation for D_square array
    printf("Enter the %d elements: \n", N);
    for(int i=0;i<N;i++){
        printf("[%d] -> ", i);
        scanf("%d", (arr+i));           //read the arr array elements one by one 
        Sum_of_ele+=*(arr+i);           //Adding of all elements into one variable 
    }
    Mean=(float)Sum_of_ele/N;                  //calculate Mean 
    for(int i=0;i<N;i++){
        arr[i]=*(arr+i)-Mean;           //calculate Deviation(D)
        D_sqr[i]=(*(arr+i)) * (*(arr+i));   //square arr array elements and store in D_sqr array
    }
    printf("Variance is %f", variance(D_sqr, N));   //Function call
}
//Function Definition
float variance(int *ptr2, int N){
   float sum_of_Dsqr=0;
   for(int i=0;i<N;i++){
       sum_of_Dsqr+=*(ptr2+i);              //calculate the all elements in D_sqr
   }
   return sum_of_Dsqr/N;             //return variance
}
