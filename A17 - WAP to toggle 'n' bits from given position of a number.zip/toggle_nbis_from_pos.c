/*
Name: Santosh Ramesh Sunagad 
Date: 31\08\2023
Description:  WAP to get 'n' bits from given position of a number
Input:Enter the number: 10
      Enter number of bits: 3
      Enter the pos: 5
Output: Result = 50
*/

#include <stdio.h>

int toggle_nbits_from_pos(int, int, int);  //Function prototype

int main()
{
    int num, n, pos, res = 0;       //declare variables
    
    printf("Enter num, n and val:");
    scanf("%d%d%d", &num, &n, &pos);
    
    res = toggle_nbits_from_pos(num, n, pos);       //Function call and result store in one variable 'res'
    
    printf("Result = %d\n", res);
}
//Function Definition
int toggle_nbits_from_pos(int num, int n, int pos){
   
    return ((((1<<n)-1)<<(pos-n+1))^num);
}