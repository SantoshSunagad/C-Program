/*
Name: Santosh Ramesh Sunagad
Date: 21\08\2023
Description: WAP to find the median of two unsorted arrays
Input:Enter the 'n' value for Array A: 5
      Enter the 'n' value for Array B: 4
      Enter the elements one by one for Array A: 3 2 8 5 4
      Enter the elements one by one for Array B: 12 13 7 5
Output: Median of array1 : 4
        Median of array2 : 9.5                                      
        Median of both arrays : 6.75 
*/

#include<stdio.h>
int main()
{
    int A, B, i, j;
    
    printf("Enter the 'n' value for Array A:");
    scanf("%d", &A);    //get the array1 size
    
    printf("Enter the 'n' value for Array B:");
    scanf("%d", &B);    ////get the array2 size
    
    int arr1[A], arr2[B];  //declare the array's
    printf("Enter the elements one by one for array A:");
    //get array elements one by one of array1
    for(i=0;i<A;i++)
        scanf("%d", &arr1[i]);
    printf("Enter the elements one by one for array B:");
    //get array elements one by one of array2
    for(i=0;i<B;i++)
        scanf("%d", &arr2[i]);
        
    //sorting of array 1
    int temp=0;
    for(i=0;i<A;i++){
        for(j=i+1;j<A;j++){
            //check the condition and sort the array elements array1
            if(arr1[j]<arr1[i]){
                temp=arr1[i];
                arr1[i]=arr1[j];
                 arr1[j]=temp;
            }
        }
    }
    
    //sorting of array 2
    int temp1=0;
    for(i=0;i<B;i++){
        for(j=i+1;j<B;j++){
     //check the condition and sort the array elements array2
            if(arr2[j]<arr2[i]){
                temp1=arr2[i];
                arr2[i]=arr2[j];
                 arr2[j]=temp1;
            }
        }
    }
    
    //To getting median value
    float median_A, median_B;
    //1st array median value
     if (A%2==0){
       median_A = (arr1[A/2] + arr1[(A/2)-1])/2.0;
       printf("Median of array1 :%.1f\n", median_A);
     }
     else
     {
          median_A = arr1[A/2];
          printf("Median of array1 :%g\n", median_A);
     }
      //2nd array median value
         if (B%2==0){
       median_B = (arr2[B/2] + arr2[(B/2)-1])/2.0;
          printf("Median of array2 :%.1f\n", median_B);
         }
       else
       {
          median_B = arr2[B/2];
          printf("Median of array2 :%g\n", median_B);
       }
       
       
    //To get median value of both array's
    float median;
    median=(median_A+median_B)/2.0;
    printf("Median of both arrays :%g\n", median);
   
    return 0;
}