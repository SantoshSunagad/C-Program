/*
Name: Santosh Ramesh Sunagad
Date: 31\08\2023
Description: WAP to implement your own isalnum() function
Input:Enter the character: a
Output:The character 'a' is an alnum character.
*/

#include <stdio.h>

int my_islower(int); //Function prototype

int main()
{
    //declare the variables
    char ch;
    int ret;
    
    printf("Enter the character:");
    scanf("%c", &ch);
    //Function call
    ret = my_islower(ch);
    /*
        Based on return value, print whether ch is lower case alphabet or not
    */
    //check the condition print accordingly
     (ret==ch)?printf("Entered character is lower case alphabet"):printf("Entered character is not lower case alphabet");
}
//Function Definition
int my_islower(int ch){
    if(ch>=97 && ch<=122)
     return ch;
     else
     return 0;
}