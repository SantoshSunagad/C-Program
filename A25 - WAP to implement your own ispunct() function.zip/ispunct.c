/*
Name: Santosh Ramesh Sunagad
Date: 31\08\2023
Description: WAP to implement your own ispunct() function
Input:Enter the character: $
Output:Entered character is punctuation character
*/

#include <stdio.h>

int my_ispunct(int); //Function prototype

int main()
{
    //declare the variables
    char ch;
    int ret;
    
    printf("Enter the character:");
    scanf("%c", &ch);
    //Function call
    ret = my_ispunct(ch);
    /*
        Based on return value, print whether ch is lower case alphabet or not
    */
     //check the condition print accordingly
    (ret==ch)?printf("Entered character is punctuation character"):printf("Entered character is not punctuation character");
}
//Function Definition
int my_ispunct(int ch){
    if((ch>=48 && ch<=57) || (ch>=97 && ch<=122) || (ch>=65 && ch<=90))
     return 0;
     else
    return ch;
}