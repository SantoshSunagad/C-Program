/*
Name: Santosh Ramesh Sunagad
Date: 05\09\2023
Description: WAP to check whether a given number is prime or not using function.
Input: Enter a number: 47
Output: 47 is a prime number
*/

#include <stdio.h>

int is_prime(int);  //Function prototype

int main()
{ 
    int num, res;
   // printf("Enter a number:");
    scanf("%d", &num);
    
    //condition to be check num is greaterthan or equal to '0'
    if(num>=0){
     res=is_prime(num); //Function call
    (res==1)?printf("%d is not a prime number", num):printf("%d is a prime number", num);
    }
    else
    printf("Invalid input");
   
    return 0;
}

//Finction Definition
int is_prime(int num){
    int flag=0;
     for(int i=2;i<num;i++){
       //condition to be check for prime number
       if(num%i==0){
           flag=1;
     }
    
}
  return flag;
}