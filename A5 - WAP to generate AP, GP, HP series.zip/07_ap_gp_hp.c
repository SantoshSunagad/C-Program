/*
Name: Santosh Ramesh Sunagad
Date: 21\08/2023
Description: WAP to generate AP, GP, HP series
Input: Enter the First Number 'A': 2
       Enter the Common Difference / Ratio 'R': 3
       Enter the number of terms 'N': 5
Output:AP = 2, 5, 8, 11, 14
       GP = 2, 6, 18, 54, 162
       HP = 0.500000, 0.200000, 0.125000, 0.090909, 0.071428
*/

#include <stdio.h>

int main() {
    int A, N, i, R;     //declare the variables
    int  temp=1;     //initialize the temp variablr by 1

    // Input
    printf("Enter the First Number 'A': ");
    scanf("%d", &A);

    printf("Enter the Common Difference / Ratio 'R': ");
    scanf("%d", &R);

    printf("Enter the number of terms 'N': ");
    scanf("%d", &N);
    
    if(N>0){

    // Arithmetic Progression (AP) seriesj
    printf("AP = ");
    for (i=0;i<N;i++) {
        printf(" %d,", A + i*R);
    }
    printf("\n");

    // Geometric Progression (GP) series
    printf("GP = %d,", A);
    for (i=0;i<N-1;i++) {
        temp=temp*R;
        printf(" %d,", temp*A);
    }
    printf("\n");

    // Harmonic Progression (HP) series
    printf("HP = ");
    for (i=0;i<N;i++) {
        printf("%f,", 1.0 / (A + i * R));
    }
    printf("\n");
}
else 
{
    printf("Invalid input");
}

    return 0;
}
//End of the program