/*
Name: Santosh Ramesh Sunagad
Date: 12\08\2023
Description: WAP to count number of set bits in a given number and print parity
Input: Enter the number:7
Output: Number of set bits = 3
        Bit parity is Odd
*/

#include<stdio.h>
int main()
{
    int num, set_bit=0, remainder;

    printf("Enter the number:");
    scanf("%d", &num);
    //run the loop below for find set bit's
   for(int i=31;i>=0;i--){
        if((num>>i)&1)
            set_bit++;
    }
    printf("Number of set bits=%d\n", set_bit);
    
    //To check if the number of set bit even or odd
    if (set_bit%2==0)
        printf("Bit parity is Even\n");
    else
          printf("Bit parity is Odd\n");
    
    return 0;
}
//End of the program