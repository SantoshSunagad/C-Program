/*
Name:Santosh Ramesh Sunagad
Date:02\09\2023
Description: Print the values in sorted order without modifying or copying array
Input:Enter the size : 7
      Enter 7 elements 
      1 3 2 5 4 7 6
Output: After sorting: 1 2 3 4 5 6 7
        Original array values 1 3 2 5 4 7 6
*/

#include <stdio.h>

void print_sort(int [], int);   //Function prototype

int main()
{
    int size, iter; //declare variables
    
    printf("Enter the size of the array : ");
    scanf("%d", &size);
    
    int arr[size];  //declare the array
    
    //read the array elements one by one
    printf("Enter the %d elements\n", size);
    for (iter = 0; iter < size; iter++)
    {
        scanf("%d", &arr[iter]);
    }
    
    print_sort(arr, size);  
}
//Function Definition
void print_sort(int arr[], int size){
    int large=*arr;
    int small=*arr;
    //To find large value in array elements
    for(int i=0;i<size;i++)
            (large<=*(arr+i))?(large=*(arr+i)):0;
    ////To find small value in array elements        
    for(int i=0;i<size;i++)
            (small>*(arr+i))?(small=*(arr+i)):0;
    
     int sec_small=large;
     
     printf("After sorting:");
     //loop run and print array element without sorting in sorting order
    do{
        for(int i=0;i<size;i++){
            if(arr[i]>small && arr[i]<sec_small){
            sec_small=arr[i];
            }
        }
     printf("%d ", small);
     small=sec_small;
     sec_small=large;
    }while(small<large);
    (large!=0)?printf("%d ", large):0;
    
 printf("\n");
 
 //loop for original array values printing
 printf("Original array values ");
 for(int i=0;i<size;i++)
 printf("%d ", *(arr+i));
}
