
/*
Name: Santosh Ramesh Sunagad
Date: 04\08/2023
Description: A1 - WAP to check if number is odd or even
Input:Enter the value of 'n' : -2
Output:-2 is negative even number
*/


#include<stdio.h>
int main()
{
int N; //declareing the variable to store user input 
printf("Enter the value of 'n':");
scanf("%d", &N); 		//read the user input
if(N % 2 == 0 && N>0)	//checking condition for positive even number
{	
	printf("%d is positive even number ", N);
	}
	else if(N % 2 ==0 && N<0)	//checking condition for negative even number
	{
	printf("%d is negative even number", N);
	}
if(N % 2 != 0 && N>0) //checking condition for positive odd number
	{
	printf("%d is positive odd number", N);
	}
	else if(N % 2 != 0 && N<0) //checking condition for negative odd number
	{
	printf("%d is negative odd number", N);
	}
else if(N == 0)  //checking if N equal to zero
{
printf("0 is neither odd nor even");
}
	return 0;
}

