/*
Name: Santosh Ramesh Sunagad
Date: 06\09\2023
Description: WAP to generate the prime series upto the given limit using functions
Input:Enter a number: 20
Output:2 3 5 7 11 13 17 19
*/
#include <stdio.h>

int is_prime(int);  //Function prototype

void generate_prime(int);   //Function prototype

int main()
{
    int limit;  //declare variable
    
    printf("Enter the limit: ");
    scanf("%d", &limit);    //read the user input
    //check the condition user input greater than 1 or not
    if (limit > 1)
    {
        generate_prime(limit);  //Function call (generate_prime)
    }
    else
    {
        printf("Invalid input\n");
    }
    
    return 0;
}

////Function Definition of (generate_prime)
void generate_prime(int num){
    int prime;  //declare variable
    for(int i=2;i<=num;i++){
        prime=is_prime(i);  //Function call (is_prime)
        (prime==i)?printf("%d ", prime):0;
    }
}
//Function Definition of (is_prime)
int is_prime(int num){
    int flag=0; //declare variable
    for(int i=2;i<num;i++){
        //condition to be check the number is prime or not
        if(num%i==0){
            flag=1; //update the flag by 1
            break;
        }
    }
    //check flag value is zero or not
    if(flag==0)
        return num;
}