/*
Name: Santosh Ramesh Sunagad
Date: 08\08\2023
Description: WAP to generate positive Fibonacci numbers
Input: Enter a number: -8
output: 0 1 1 2 3 5 8
*/


#include<stdio.h>
int main()
{
    int sub, N;  //declare the variables 
    int a=0, b=1;   // initialize the a and b variables
    printf("Enter a number:");
    scanf("%d", &N);    //read the user input and store in 'N' variable
    
    //check the condition foe given number is positive or negative
    if(N<=0){       
        
        //loop run untill any one condition  gets falls
        while(a>=N && a<=-N){       
            printf(" %d", a);
            sub=a-b;
            a=b;        //swiping a in b
            b=sub;      //swiping b in 'sub' value
        }
    } 
    else
    {
        printf("Invalid input");
    }
    
    
    return 0;
}
//End the program