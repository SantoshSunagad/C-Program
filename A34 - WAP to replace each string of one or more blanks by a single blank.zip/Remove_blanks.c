/*
Name: Santosh Ramesh Sunagad
Date: 03\10\2023
Description:WAP to replace each string of one or more blanks by a single blank
Input:Enter the string with more spaces in between two words
      Welcome                to Emertxe
Output: Welcome to Emertxe
*/
#include <stdio.h>

void replace_blank(char []);    //Function prototype

int main()
{
    char str[300];       //declare the string array
    
    //printf("Enter the string with more spaces in between two words\n");
    scanf("%[^\n]", str);       //read user input 
    
    replace_blank(str);         //Function call
    
    printf("%s\n", str);
}
//Function Definition
void replace_blank(char str[]){
    int temp=0; //Taking temp variable and assign zero
        for(int i=0;str[i]!='\0';i++){
           
            if(str[i]==' ' && str[i-1]==' ')    //condition to be check morethan one space present or not
                    continue;
                    str[temp++]=str[i];
        }
        str[temp]='\0';     //Adding NULL character 
}