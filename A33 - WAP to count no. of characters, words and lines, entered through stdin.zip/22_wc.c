/*
Name: Santosh Ramesh Sunagad 
Date: 25/11/2023
Description:A33 - WAP to count no. of characters, words and lines, entered through stdin
Sample Input:./my_wc
Sample Output:Hello world
       Dennis Ritchie
       Linux
       Character count : 33
       Line count : 3
       Word count : 5
*/

#include<stdio.h>
int main()
{
	char ch, prev_character = ' ';  
	int wordcount = 0, charcount = 0, linecount = 0; 
	__fpurge(stdin); 
	while((ch = getchar()) != EOF)  
	{
	    charcount++;
		if((prev_character != ' ' && prev_character != '\n' && prev_character != '\t') && (ch == '\t' || ch == ' ' || ch == '\n' || ch == '\0'))
		{
		    wordcount++;
		}
		prev_character = ch;
		if(ch == '\n') 
		{
		    linecount++;  
		}
	}
	if(prev_character != '\n' && ch == EOF)
	{
		wordcount += 1; 
	}
	printf("Character count : %d\n", charcount);
	printf("Line count : %d\n", linecount);
	printf("Word count : %d\n", wordcount);
    return 0;
}