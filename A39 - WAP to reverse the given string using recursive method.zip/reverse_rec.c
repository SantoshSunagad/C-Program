/*
Name:Santosh Ramesh Sunagad
Date:05\10\2023
Description: WAP to reverse the given string using recursive method
Input:Enter a string : Hello World
Output: Reverse string is : dlroW olleH
*/
#include <stdio.h>
#include<string.h>

void reverse_recursive(char str[], int i, int len);   //Function Prototype

int main()
{
    char str[30];   //declare character array
    
    
    printf("Enter any string : ");
    scanf("%[^\n]", str);
    int len=strlen(str)-1;    //to get string length
    int i=0;
    reverse_recursive(str, i, len);       //Function call
    
    printf("Reversed string is %s\n", str);
}

//Function Definition (To reverse the string)
void reverse_recursive(char str[], int i, int len){
        char temp;
       
          if(i <len)          
            {
                //swapping 
	            temp = str[i];                 
        	    str[i] = str[len];        
        	    str[len] = temp;
        	    len--;
        	    i++;
        	    reverse_recursive(str,i,len);         //Function calling recursively
            }
}       