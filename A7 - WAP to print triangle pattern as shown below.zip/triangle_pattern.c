/*
Name: Santosh Ramesh Sunagad
Date: 09\08/2023
Description:  WAP to print triangle pattern as shown below
Input:  Enter the number: 5
Output:
        1 2 3 4 5
        6     7
        8   9
        10 11
        12
*/

#include <stdio.h>
int main()
{
    int i,n,j;      //declare the variable
    int count=1;    //initialize the count variable by 1
    
    printf("Enter the number:");
    scanf("%d", &n);        //read the user input
    
    //Outer loop
    for ( i=1; i<=n; i++)
    {
        
        //inner loop
        for (j=1; j<=n; j++)
        {
            //check the condition in '||' logic operator 
            if ( i==1 || j==1 || i+j==n+1)  
            {
            printf("%d ",count);
            count=count+1;      //update the count variable by 1
        }
            else
            //space printing
                printf(" ");
        }
        printf("\n");   //Move to next line
    }
    return 0;
}
//End the program