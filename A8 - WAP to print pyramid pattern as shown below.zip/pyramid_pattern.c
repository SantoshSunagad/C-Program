/*
Name: Santosh Ramesh Sunagad
Date: 18\08\2023
Description: WAP to print pyramid pattern as shown below
Input: Enter the number: 4
Output 5
       4 5
       3 4 5
       2 3 4 5
       1 2 3 4 5
       2 3 4 5
       3 4 5
       4 5
       5
*/

#include<stdio.h>
int main()
{
    int n, j, i;    //declare the variables
    
    printf("Enter the number:");
    scanf("%d", &n);    //read the user input
    
    //run the loops according to condition and genrate pattern
    for(i=n;i>=1;i--){
        for(j=i;j<=n;j++){
            printf("%d ", j);
        
        }
        printf("\n");
    }
    
    for(i=2;i<=n;i++){
        for(j=i;j<=n;j++){
            printf("%d ", j);
        }
        printf("\n");
    }
    
    return 0;
}
//End the program
