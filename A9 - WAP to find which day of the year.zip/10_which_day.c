/*
Name: Santosh Ramesh Sunagad
Date: 17\08/2023
Description: A4 - WAP to check if number is perfect or not
Input:    Enter the value of 'n' : 9
          Choose First Day :
          1. Sunday
          2. Monday
          3. Tuesday
          4. Wednesday
          5. Thursday
          6. Friday
          7. Saturday
          Enter the option to set the first day : 2
Output:  The day is Tuesday
*/

#include<stdio.h>
int main()
{
    int n, day, temp;
    
    printf("Enter the value of 'n':");
    scanf("%d", &n);
    
    //check the condition user input is between 1-365 or not
     if(1<=n && n<=365)
    {
    printf("Choose First Day :\n 1. Sunday\n 2. Monday\n 3. Tuesday\n 4. Wednesday\n 5. Thursday\n 6. Friday\n 7. Saturday \n Enter the option to set the first day:");
    scanf("%d", &day);
        
        //check user input is between 1-7 or not
        if(1<=day && day<=7)
        {
            temp=(n+day-1)%7;
            //Run the switch case according temp value
                switch (temp)
                {
                    case 1: printf("The day is Sunday");
                            break;
                    case 2: printf("The day is Monday");
                            break;
                    case 3: printf("The day is Tuesday");
                            break;
                    case 4: printf("The day is Wednesday");
                            break;
                    case 5: printf("The day is Thursday");
                            break;
                    case 6: printf("The day is Friday");
                            break;
                    case 0: printf("The day is saturday");
                            break;
                }
        }
    else
    {
        printf("Error: Invalid input, first day should be > 0 and <= 7");
    }
    }
    else
    {
        printf("Error: Invalid Input, n value should be > 0 and <= 365");
    }
    
    return 0;
}
//End the progrm