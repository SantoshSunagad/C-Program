/*
Name: Santosh Ramesh Sunagad
Date: 29\09\2023
Description: WAP to reverse the given string using iterative method
Input: EMERTXE
Output: EXTREME
*/

#include <stdio.h>

void reverse_iterative(char str[]); //Function Prototype
int string_length(char str[]);

int main()
{
    char str[30];   //declare string
    
    printf("Enter any string : ");
    scanf("%[^\n]", str);   //read user string
  
    reverse_iterative(str); //Function call
    
    printf("Reversed string is %s\n", str);
}


//Function Definition (To reverse the string)
void reverse_iterative(char str[]){
        int length=string_length(str);
        int j=length,i=0;
        char temp;
           while(i<j){
                temp=str[i];
                str[i]=str[j];
                str[j]=temp;
                j--;
                i++;
            }
}       
        
//Function Definition (To get string length)
int string_length(char str[]){
    int count=0;
    while(*(str)++!='\0')
        count++;
        return count-1;
}