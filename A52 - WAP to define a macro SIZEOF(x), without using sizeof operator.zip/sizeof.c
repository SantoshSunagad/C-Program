/*
Name: Santosh Ramesh Sunagad
Date: 10\10\2023
Description:WAP to define a macro SIZEOF(x), without using sizeof operator
Input:
Output:Size of int : 4 bytes
       Size of char : 1 byte
       Size of float : 4 bytes
       Size of double : 8 bytes
       Size of unsigned int : 4 bytes
       Size of long int : 8 bytes
*/

#include<stdio.h>
#define SIZEOF(X)       (char *) (&X+1) - (char *)(&X)      // Define a macro to calculate the size of datatype   

int main()
{
    //declare variables
    int x;
    char A;
    float B;
    double C;
    unsigned int D;
    long long int E;
    long double F;
    short int G;
    unsigned char H;
    signed long int I;
    unsigned long int J;
    signed short int K;
    
    printf("Size_of int : %ld bytes\n", SIZEOF(x));
    printf("Size_of char : %ld bytes\n", SIZEOF(A));
    printf("Size_of float : %ld bytes\n", SIZEOF(B));
    printf("Size_of double : %ld bytes\n", SIZEOF(C));
    printf("Size_of unsigned int : %ld bytes\n", SIZEOF(D));
    printf("Size_of long long int : %ld bytes\n", SIZEOF(E));
    printf("Size_of long double : %ld bytes\n", SIZEOF(F));
    printf("Size_of short int : %ld bytes\n", SIZEOF(G));
    printf("Size_of unsigned char : %ld bytes\n", SIZEOF(H));
    printf("Size_of signed long int : %ld bytes\n", SIZEOF(I));
    printf("Size_of unsigned long int : %ld bytes\n", SIZEOF(J));
    printf("Size_of signed short int : %ld bytes\n", SIZEOF(K));
    
    
}