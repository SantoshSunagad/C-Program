/*
Name: Santosh Ramesh Sunagad
Date: 31\08\2023
Description: WAP to implement your own isalnum() function
Input:Enter the character: a
Output:The character 'a' is an alnum character.
*/

#include <stdio.h>

int my_isalnum(int);    //Function prototype

int main()
{
    //declare the variables
    char ch;    
    int ret;
    
    printf("Enter the character:");
    scanf("%c", &ch);   
    //Function call
    ret = my_isalnum(ch);
    /*
        Based on return value, print whether ch is alphanumeric or not
    */
    //check the condition print accordingly
    (ret==ch)?printf("Entered character is alphanumeric character"):printf("Entered character is not alphanumeric character");

    return 0;
}

//Function Definition
int my_isalnum(int ch){
    if((ch>=48 && ch<=57) || (ch>=97 && ch<=122) || (ch>=65 && ch<=90))
     return ch;
     else
     return 0;
}