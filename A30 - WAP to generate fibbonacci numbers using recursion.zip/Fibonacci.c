/*
Name: Santosh Ramesh Sunagad
Date: 01\09\2023
Description: WAP to generate fibbonacci numbers using recursion
Input:Enter a number: 8
Output: 0, 1, 1, 2, 3, 5, 8
*/

#include <stdio.h>

void positive_fibonacci(int, int, int, int);    //Function prototype

int main()
{
    int limit;
    
    printf("Enter the limit : ");
    scanf("%d", &limit);
    
    positive_fibonacci(limit, 0, 1, 0); //Function call in main Function
}
//Function Definition
void positive_fibonacci(int limit, int a, int b, int fib_series){
    if(limit>=0){   //condition to be check limit is greater than 0 or not
            if(fib_series<=limit){
                 printf("%d, ", fib_series);
                //swapping numbers
                a=b;
                b=fib_series;
                fib_series=a+b;     //to genrate next fibonacci number
                positive_fibonacci(limit, a, b, fib_series);    //Function call recursively
            }
    }
    else
    printf("Invalid input");
} 